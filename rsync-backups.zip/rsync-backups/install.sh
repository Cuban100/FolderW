#!/bin/bash

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Verify if Python is installed
if ! command_exists python3; then
    echo "Python3 is not installed. Please install Python3 and try again."
    exit 1
fi

# Create the virtual environment in the root of the project
ENV_DIR="venv"

# Create the virtual environment
echo "Creating virtual environment in '$ENV_DIR'..."
python3 -m venv $ENV_DIR

# Check if the virtual environment was created successfully
if [ $? -ne 0 ]; then
    echo "Failed to create virtual environment."
    exit 1
fi


# Make the activation script executable
chmod +x activate_venv.sh

# Inform the user
echo "Virtual environment created and setup script generated."
echo "To activate the virtual environment and complete the setup, run:"
echo "source activate_venv.sh"
