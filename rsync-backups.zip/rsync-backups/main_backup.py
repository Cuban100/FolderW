import os
from dotenv import load_dotenv
import subprocess
import schedule
import time
from loguru import logger

# Load configuration from .env file
load_dotenv()

MONITOR_SOURCE_FOLDER = os.getenv('MONITOR_SOURCE_FOLDER', '0')

# Function to run the regular backup
def run_regular_backup():
    logger.info("Running regular backup with rsync_incremental.py")
    subprocess.run(["python", "rsync_incremental.py"])

# Function to start the event-driven backup
def start_event_backup():
    logger.info("Starting event-driven backup with rsync_event_handler.py")
    subprocess.run(["python", "rsync_event_handler.py"])

# Function to start the appropriate backup method
def start_backup():
    if MONITOR_SOURCE_FOLDER == '1':
        start_event_backup()
    else:
        run_regular_backup()

if __name__ == "__main__":
    # Perform an immediate backup upon startup
    start_backup()

    # Schedule regular backup every hour if not monitoring the source folder
    if MONITOR_SOURCE_FOLDER != '1':
        schedule.every().hour.do(run_regular_backup)
        logger.info("Scheduled hourly regular backup")

    while True:
        schedule.run_pending()
        time.sleep(1)
