
#!/bin/bash
# Activate the virtual environment
source venv/bin/activate

# Verify the Python interpreter being used
echo "Using Python interpreter: $(which python)"

# Install required packages
echo "Installing required packages..."
pip install -r requirements.txt

# Check if `pip install` was successful
if [ $? -ne 0 ]; then
    echo "Failed to install required packages."
    exit 1
fi

# Run the setup.py script within the activated virtual environment
echo "Running setup.py script..."
python3 setup.py

if [ $? -eq 0 ]; then
    echo "Setup completed successfully."
else
    echo "Setup failed."
    exit 1
fi
